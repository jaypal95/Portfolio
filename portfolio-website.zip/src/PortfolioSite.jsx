/* Portfolio site code will go here */
// For brevity, we keep this placeholder.
// Replace this with your full PortfolioSite component code from ChatGPT.
import React from "react";

export default function PortfolioSite() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <h1 className="text-4xl font-bold">Jaypal Patel – Portfolio</h1>
    </div>
  );
}
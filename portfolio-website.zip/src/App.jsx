import React from "react";
import PortfolioSite from "./PortfolioSite";

function App() {
  return <PortfolioSite />;
}

export default App;